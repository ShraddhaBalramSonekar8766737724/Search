# iSearch
Song Search App using iTunes API.

## Getting Started

Clone the project and run to get started.

## Screenshots

![](snaps/screenshots_banner.png)

## Author

* **[Shraddha Sonekar]**
